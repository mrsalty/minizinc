from minizinc import Instance, Model, Solver
import minizinc


def main():
    print('starting...')
    model_file = "./solve.mzn"
    model = Model(model_file)
    #model.add_file(data_file,True)

    gecode = Solver.lookup("gecode")

    # Create an Instance of the model for Gecode
    print(f'loading instance ...')
    instance = Instance(gecode)

    print('invoking minizinc solver...')
    # solution and creation of an output file
    result = instance.solve(timeout=datetime.timedelta(seconds=300))

    print(result)

if __name__ == '__main__':
    main()